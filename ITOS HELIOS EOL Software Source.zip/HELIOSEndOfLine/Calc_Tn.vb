﻿Module Calc_Tn
    Declare Function Lambda_dom Lib "Calc_Tn.dll" (ByVal CIE_x As Double, ByVal CIE_y As Double) As Double
End Module
